# Verficiador

Implementa un verificador de contexto que realiza las siguientes tareas:

- Análisis de identificación
- Inferencia de tipo
