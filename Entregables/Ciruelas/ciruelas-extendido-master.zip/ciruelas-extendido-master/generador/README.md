# Generador

Implementa un generador de código basado en el patrón vistante y una estrategia de arriba-abajo

