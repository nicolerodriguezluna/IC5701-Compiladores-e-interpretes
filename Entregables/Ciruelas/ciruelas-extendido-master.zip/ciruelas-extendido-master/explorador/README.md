# Explorador

Implementa el explorador y permite visualizar una lista de componentes léxicos si así lo requiere el usuario. Este módulo se accede desde el archivo ciruelas.py mediante argumentos de la línea de comandos.


